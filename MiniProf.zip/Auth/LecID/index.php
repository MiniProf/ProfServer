<?php
include_once '../../API.php';
class StartPoll extends API
{
  public function doAPI(){
    return ($this->USERID);

  }
}
new StartSession(true);
?>

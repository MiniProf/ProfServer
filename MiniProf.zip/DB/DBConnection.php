<?php
$GLOBALS['DBConnection'] = new mysqli('wilsonator.co.uk.mysql','wilsonator_co_u','CXUDRIU255RMHVWM','wilsonator_co_u');

?>
